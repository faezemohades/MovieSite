import Col from 'react-bootstrap/Col';
import React, { useEffect, useState } from "react";
import Container from "react-bootstrap/Container";
import Row from 'react-bootstrap/Row';
import dgirl from "../assets/image/girl.png";
import dboy from "../assets/image/boy.png";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import MyHelmet from '../Components/MyHelmet';
import avatarPic from '../data/avatar.json';
import Loading from '../Components/Loading';

//import covergirl1440 from '../assets/image/Girl-1440.360.png';
//import covergirl480 from '../assets/image/Girl-480.270.png';

//import coverboy1440 from '../assets/image/Boy-1440.360.png';
//import coverboy480 from '../assets/image/Boy-480.270.png';


function Profile() {

    //loader goes here
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (loading) {
            setTimeout(() => {
                setLoading(false);
            }, 500);
        }
    }, [loading]);


    //toggle checked between girl and boy 
    const [isGirlVisible, setIsGirlVisible] = useState(false);
    const [isBoyVisible, setIsBoyVisible] = useState(false);

    const handleGirlPress = () => {
        setIsGirlVisible((isVisible) => !isVisible);
        setIsBoyVisible(false);
    };

    const handleBoyPress = () => {
        setIsBoyVisible((isVisible) => !isVisible);
        setIsGirlVisible(false);
    };

    //set emoji and avatar in cookie

    const [setEmoji] = useState(avatarPic.emojis[0].image)
   
    //register button and handle color theme
    const [girlSelected, setGirlSelected] = useState(false);
    const [boySelected, setBoySelected] = useState(false); 

    let navigate = useNavigate();

    const routeChange = () => {
        if (girlSelected) {
            localStorage.setItem("theme", "rgb(228,89,158)");
            //localStorage.setItem("coverl440", covergirl1440);
            //localStorage.setItem("cover480", covergirl480);
        }
        else if (boySelected) {
            localStorage.setItem("theme", "rgb(54, 183, 223)");
            //localStorage.setItem("coverl440", coverboy1440);
            //localStorage.setItem("cover480", coverboy480);
        }
        let path ="/";
        navigate(path);
        window.location.reload(false);
      }
     
     //handle header color
    const themeColor = localStorage.getItem("theme");

    useEffect(() => {
       
        document.body.style.backgroundColor = themeColor;

        if (themeColor === "rgb(228,89,158)" ) {

            document.getElementById("nav").classList.add("girl-color");
        }

        else if (themeColor === "rgb(54, 183, 223)") {

            document.getElementById("nav").classList.add("boy-color");


        }

    }, [themeColor]);
 
    return (
        <Container style={{ marginTop:"80px" }}>

            {loading ?
                <Loading /> : (
                <>
                        <Row>
                           
                            <MyHelmet title='تنظیمات پروفایل' description="تنظیمات پروفایل" url="https://kids.mp4.ir/profile" />
                            <Col>

                                 {/*title of page goes here*/}

                                <div  className="d-flex justify-content-center align-items-center" style={{ borderRadius: "5px", background:"rgba(36, 36, 36, 0.23)" }} >
 
                                    <h3 style={{ color: "white", marginTop: "20px", marginBottom: "20px" }}> ایموجی خودت رو انتخاب کن!</h3>
                                </div>

                    <div className="d-flex justify-content-center align-items-center mb-5">

                                    <div className="text-white d-flex">

                                        {/*girl and boy  button of theme goes here*/}

                            <motion.div className="d-flex flex-column align-items-center"

                                animate={{ x: -5 }}
                                            transition={{ type: "spring", stiffness: 100 }}
                                            onClick={() => setBoySelected(true)}
                            >
                                            <div className="d-flex flex-column align-items-center">
                                            <img src={dboy} alt="پسر" onClick={handleBoyPress} className="genderbtn mt-5" />

                                                <h6 className="m-0">پسر</h6>
                                                {isBoyVisible && <div class="wrapper d-flex flex-column align-items-start">
                                                    <div class="tick"></div>
                                                </div>}
                                            </div>

                                            
                                        </motion.div>

                            <motion.div className="d-flex flex-column align-items-center"
                                animate={{ x: -5 }}
                                            transition={{ type: "spring", stiffness: 100 }}
                                            onClick={() => setGirlSelected(true)}
                                        >
                                            <div className="d-flex flex-column align-items-center">
                                            <img src={dgirl} alt="دختر"  onClick={handleGirlPress} className="genderbtn mt-5 mb-1" />
                                            
                                            <h6 className="m-0">دختر</h6>
                                                {isGirlVisible && <div class="wrapper d-flex flex-column align-items-start">
                                                    <div class="tick"></div>
                                                </div>}
                                            </div>
                            </motion.div>

                        </div>
                    </div></Col>
                </Row>

                <Row>

                              {/*emojis box goes here*/}

                            <div className="d-flex justify-content-center flex-wrap">

                        {
                            avatarPic.emojis.map((item) =>
                            (<motion.div className="d-flex flex-column align-items-center"
                                animate={{ x: 5 }}
                                transition={{ type: "spring", stiffness: 100 }}
                                key={item.id}
                            >

                                <img src={item.image} alt={item.title} className="avatar selectable-item" tabIndex={0}  onClick={() => { localStorage.setItem("avatar", item.image); setEmoji(item.emoji) }} />

                            </motion.div>
                            ))
                        }
                            </div>
                            <div className="d-flex justify-content-center mt-5 mb-2">
                            <button  className="register-btn" onClick={routeChange}>
                                ثبت
                            </button>
                            </div>
                   

                    </Row>
                </>
            )}
          
        </Container>
    )
}

export default Profile