﻿ import React, { useState } from 'react';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Slider from "react-slick";
import Loading from './Loading';
import { useEffect } from 'react';
import AnimeCard from './AnimeCard';
import axios from "axios";
import { useNavigate } from "react-router-dom";


const Setting = {
    arrows: false,
    dots: false,
    infinite: true,
    slidesToShow: 5,
    slidesToScroll: 2,
    speed: 500,
    swipeToSlide: true,
    autoplay: true,
    responsive: [
        {
            breakpoint: 1440,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 1,
                infinite: true,
                dots: false
            }
        },
        {
            breakpoint: 1300,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 1,
                infinite: true,
                dots: false
            }
        },
        {
            breakpoint: 1024,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
                infinite: true,
                dots: false,
                arrows: false,

            }
        }, ,
        {
            breakpoint: 900,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
                infinite: true,
                dots: false,
                arrows: false,

            }
        },
        {
            breakpoint: 768,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                initialSlide: 1,
                arrows: false,

            }
        },
        {
            breakpoint: 600,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                initialSlide: 1,
                arrows: false,

            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: false,


            }
        },
        {
            breakpoint: 375,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: false,


            }
        },
        {
            breakpoint: 320,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: false,


            }
        }

    ]
}

function Anime() {
    const [loading, setLoading] = useState(true);
    const [VideoItems, setVideoItems] = useState();
    const [notFound, setNotFound] = useState(false);
    const [isResponse, setIsResponse] = useState(false);


    const navigate = useNavigate();

    useEffect(() => {
        setLoading(true)
        axios.get(`https://www.mp4.ir/mp4kids/api/Cinema?startrow=0&endrow=20`)
            .then((response) => {
    
                setVideoItems(response.data);
                setIsResponse(true);
            }).catch((error) => {
                 setNotFound(true);
            }).finally(() => setLoading(false)); 
    }, []);

    useEffect(() => {
        if (isResponse) {
            navigate('/');
        }
    }, [isResponse]);

    useEffect(() => {
        if (notFound) {
            navigate('/404');
        }
    }, [notFound]);


    return (
        <Container fluid className="home-char" >

            {loading ? <Loading /> :
                (
                    <>
                        <Row>
                            <Col className="text-light mt-2">
                                <div className="home-row">
                                    <p className="home-char-title">سینمایی</p>
                                </div>
                            </Col>
                        </Row>
                        <Row className="p-0" className="d-flex justify-content-center">
                            <Col lg={12} md={12} sm={11} xs={12}  >
                                <div className=" p-0 " >
                                    <div className="my-1 mx-2 py-0" >
                                        <Slider {...Setting}>
                                            {VideoItems && VideoItems.map((movie, id) => (
                                                <AnimeCard key={id} movie={movie} />
                                            ))}
                                        </Slider>
                                         
                                    </div>
                                </div>
                            </Col>
                        </Row>
                    </>
                )}

        </Container>

    );
}

export default Anime;

