﻿    import React, { useState, useEffect } from "react"; 
    import Container from "react-bootstrap/Container"; 
    import Modal from "react-bootstrap/Modal"; 
    import { motion } from "framer-motion"; 
    import Row from 'react-bootstrap/Row'; 
    import { FaWindowClose } from 'react-icons/fa'; 
    import dgirl from "../assets/image/girl.png"; 
    import dboy from "../assets/image/boy.png"; 
    import avatarPic from '../data/avatar.json'; 
    import { BiCheck } from 'react-icons/bi';

    //import covergirl1440 from '../assets/image/Girl-1440.360.png';
    //import covergirl480 from '../assets/image/Girl-480.270.png';

    //import coverboy1440 from '../assets/image/Boy-1440.360.png';
    //import coverboy480 from '../assets/image/Boy-480.270.png';

function GenderModal(props) { 

    const avatar = localStorage.getItem("avatar");

    //handling close and fullscreen modal

    const [dp, setDp] = useState(true);
    const [fullscreen] = useState(true);


    //handle checked girl or boy
    const [isGirlVisible, setIsGirlVisible] = useState(false);
    const [isBoyVisible, setIsBoyVisible] = useState(false);


    //handle girl or boy selected for theme
    const [girlSelected, setGirlSelected] = useState(false);
    const [boySelected, setBoySelected] = useState(false); 

    const [avatarSelected, setAvatarSelected] = useState(false);


    //set theme and avatar in cookie
    const [emoji, setEmoji] = useState(avatarPic.emojis[0].image)
     



    //toggle between boy and girl color of theme
    const handleGirlPress = () => {
        setIsGirlVisible((isVisible) => !isVisible);
        setIsBoyVisible(false);
    };

    const handleBoyPress = () => {
        setIsBoyVisible((isVisible) => !isVisible);
        setIsGirlVisible(false);
    };


    // theme handler

    const themeHandler=()=>{ 
 
        if (avatarSelected && !girlSelected) { 
            localStorage.setItem("avatar", emoji);
            window.location.reload(false); 
            setDp(false);
         
        } 
         
        else if (!avatarSelected && girlSelected) { 
             localStorage.setItem("theme", "rgb(228,89,158)");
     
            localStorage.setItem("avatar",avatarPic.emojis[1].image);

            window.location.reload(false);
            setDp(false);
            //set girl cover image
            //localStorage.setItem("coverl440", covergirl1440);
            //localStorage.setItem("cover480", covergirl480);
        } 

        else if(girlSelected) { 
            localStorage.setItem("theme", "rgb(228,89,158)");
            document.getElementById("nav").classList.add("girl-color"); 
            window.location.reload(false);
            setDp(false);
            //set girl cover image
            //localStorage.setItem("coverl440", covergirl1440);
            //localStorage.setItem("cover480", covergirl480);

        } 


        if (avatarSelected && !boySelected) {
            localStorage.setItem("avatar", emoji);
             window.location.reload(false); 
          setDp(false);
          //set default cover image
        
      } 

        else if (!avatarSelected && boySelected) { 
           localStorage.setItem("theme", "rgb(54, 183, 223)");

            localStorage.setItem("avatar", avatarPic.emojis[0].image);

          window.location.reload(false);
          setDp(false);
          //set boy cover image
          //localStorage.setItem("coverl440", coverboy1440);
          //localStorage.setItem("cover480", coverboy480);
      }

         else if(boySelected) { 
          localStorage.setItem("theme", "rgb(54, 183, 223)");
           document.getElementById("nav").classList.add("boy-color"); 
          window.location.reload(false); 
          setDp(false);
          //set boy cover image
          //localStorage.setItem("coverl440", coverboy1440);
          //localStorage.setItem("cover480", coverboy480);
         }
    } 
 
    //handle header color

        const themeColor = localStorage.getItem("theme");
    useEffect(() => {
        document.body.style.backgroundColor = themeColor; 
 
        if (themeColor === "rgb(228,89,158)") {
             document.getElementById("nav").classList.add("girl-color");
        }

        else if (themeColor === "rgb(54, 183, 223)") {
             document.getElementById("nav").classList.add("boy-color");
         }
         else { document.getElementById("nav").classList.add("default-color"); }
 
    }, [themeColor]); 



    return ( 
      
      <>
          {((  avatar === emoji) && dp) && 
 
                <Modal show={props.show}
                    fullscreen={fullscreen} > 
                   
                  {/*close button */}

                  <div > 
                      <FaWindowClose size={30} color='white' onClick={props.close} style={{ marginInline: "8px",cursor:"pointer" ,marginTop:"8px"}} /> 
                  </div> 
                    <div className="gmodal">
                  <Container> 
                      <Row  > 

                          {/*title of modal*/}

                            <motion.div className="d-flex justify-content-center align-items-center  " 
                              initial={{ opacity: 0, scale: 0.5 }} 
                              animate={{ opacity: 1, scale: 1 }} 
                              transition={{ 
                                  default: { 
                                      duration: 0.3, 
                                      ease: [0, 0.71, 0.2, 1.01] 
                                  }, 
                                  scale: { 
                                      type: "spring", 
                                      damping: 5, 
                                      stiffness: 100, 
                                      restDelta: 0.001 
                                  } 
                              }} > 
                                <h4 style={{ color: "white"}}> ایموجی خودت رو انتخاب کن
                                        !
                                    </h4> 
                          </motion.div> 

                                <motion.div className="d-flex justify-content-center align-items-center "
                                    initial={{ opacity: 0, scale: 0.5 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    transition={{
                                        default: {
                                            duration: 0.3,
                                            ease: [0, 0.71, 0.2, 1.01]
                                        },
                                        scale: {
                                            type: "spring",
                                            damping: 5,
                                            stiffness: 100,
                                            restDelta: 0.001
                                        }
                                    }}
                                >
                                    {/*girl and boy button */}
                                    <div className="text-white d-flex ">

                                        <motion.div className="d-flex flex-column align-items-center" whileHover={{ scale: 0.9 }} transition={{
                                            opacity: { ease: "linear" },
                                            layout: { duration: 0.3 }
                                        }}
                                            onClick={() => setBoySelected(true)}
                                        >
                                            <div className="d-flex flex-column align-items-center">
                                                <img src={dboy} alt="پسر" onClick={handleBoyPress} className="genderbtn mt-5" />

                                                <h6 className="m-0">پسر</h6>
                                                {isBoyVisible && <div class="wrapper d-flex flex-column align-items-start">
                                                    <div class="tick"></div>
                                                </div>}
                                            </div>
                                        </motion.div>


                                        <motion.div className="d-flex flex-column align-items-center" whileHover={{ scale: 0.9 }} transition={{
                                            opacity: { ease: "linear" },
                                            layout: { duration: 0.3 }
                                        }}
                                            onClick={() => setGirlSelected(true)}
                                        >
                                            <div className="d-flex flex-column align-items-center">
                                                <img src={dgirl} alt="دختر" onClick={handleGirlPress} className="genderbtn mt-5 mb-1" />

                                                <h6 className="m-0">دختر</h6>
                                                {isGirlVisible && <div class="wrapper d-flex flex-column align-items-start">
                                                    <div class="tick"></div>
                                                </div>}
                                            </div>
                                        </motion.div>

                                    </div>

                                </motion.div> 
                          {/*avatar box goes here*/}

                          <div className="d-flex justify-content-center flex-wrap mt-1"> 
                              { avatarPic.emojis.slice(0, 8).map((item) => ( 
                                      <motion.div className="d-flex justify-content-center" 
                                          animate={{ x: 10 }} 
                                          transition={{ type: "spring", stiffness: 100 }}
                                            key={item.id} 
                                      > 
 
                                      <img src={item.image} alt={item.title} className="avatar selectable-item" tabIndex={0}
                                          onClick={() => { localStorage.setItem("avatar", item.image); setAvatarSelected(true); setEmoji(item.image) }} /> 
                                      </motion.div> 
                                  )) 
                              } 
                          </div> 
                      </Row> 
                  </Container> 
 
               

                  {/*register button*/}

                     <div className="d-flex justify-content-center mt-lg-2">
                     <button className=" register-btn" onClick={themeHandler}>
                                ثبت
                      </button>
                       </div>
                
                     </div>
              </Modal> 
 
            } 
          
      </> 
  ); 
} 
 
export default GenderModal;