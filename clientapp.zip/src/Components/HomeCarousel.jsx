﻿import React, { useEffect, useState } from 'react';
import Slider from "react-slick";
import CustomSlide from '../Components/CustomSlide';
import axios from "axios";
import { useNavigate } from "react-router-dom";
 
 
function HomeCarousel() {
   
    //fetch API goes here

    const [slideShow, setSlideShow] = useState([]);
    const [notFound, setNotFound] = useState(false);
    const [isResponse, setIsResponse] = useState(false);


    const navigate = useNavigate();

    const fetchData = async () => {
        await axios.get(`https://demoservice.mp4.ir/mp4kids/api/GetSliders`)
            .then((response) => {
                setSlideShow(response.data);
                setIsResponse(true);

              })
            .catch((error) => {
                 setNotFound(true);
            });
    }

    useEffect(() => {
        fetchData();
    }, []);


    useEffect(() => {
        if (isResponse) {
            navigate('/');
        }
    }, [isResponse]);

    useEffect(() => {
        if (notFound) {
            navigate('/404');
        }
    }, [notFound]);


    // slider setting
    const settings = {
        dots: true,
        infinite: true,
        speed: 1200,
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        autoplay: true,
        lazyLoad: true,
    };
   
    return (
        <>
            
            <div className="slider-img" style={{ marginTop: "55px"}} >
                <section className="grad1">
                    <Slider {...settings}>
                        {slideShow.map((item) => (
                         <CustomSlide item={item} key={item.id} />
                        ))}
                    </Slider>
                </section>


            </div>
        
        </>
  );
}

export default HomeCarousel;