﻿//import React from 'react';
//import Col from 'react-bootstrap/Col';
//import coverd1440 from '../assets/image/Diff-1440.360.png';
//import coverd480 from '../assets/image/Diff-480.270.png';


//function Cover() {
//    const cover1440 = localStorage.getItem("coverl440");
//    const cover480 = localStorage.getItem("cover480");

//    return (


//        <Col className="p-0 mt-5">
            
//            {(cover1440 && cover480) ?
//                <picture>
//                <source media="(min-width:1440px)" srcSet={cover1440} width="100%" height="auto" />
//                <source media="(max-width: 479px)" srcSet={cover480} width="100%" height="auto" />
//                <img src={cover1440} alt="کاور" width="100%" height="100%" />
//                </picture>
//                :
//                <picture>
//                    <source media="(min-width:1440px)" srcSet={coverd1440} width="100%" height="auto" />
//                    <source media="(max-width: 479px)" srcSet={coverd480} width="100%" height="auto" />
//                    <img src={coverd1440} alt="کاور" width="100%" height="100%" />
//                </picture>
//            }
               
//            </Col>

//     );
//}

//export default Cover