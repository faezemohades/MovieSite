﻿import React, { useState } from 'react';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Slider from "react-slick";
import character from '../data/character.json';
import HomeCharCard from './HomeCharCard';
import Loading from './Loading';
import { useEffect } from 'react';

const Setting = {
    arrows: false,
    dots: false,
    infinite: true,
    slidesToShow: 8,
    slidesToScroll: 2,
    speed: 500,
    swipeToSlide: true,
    autoplay: true,
    responsive: [
        {
            breakpoint: 1300,
            settings: {
                slidesToShow: 7,
                slidesToScroll: 1,
                infinite: true,
                dots: false
            }
        },
        {
            breakpoint: 1024,
            settings: {
                slidesToShow: 6,
                slidesToScroll: 1,
                infinite: true,
                dots: false,
                arrows: false,

            }
        }, ,
        {
            breakpoint: 900,
            settings: {
                slidesToShow: 5,
                slidesToScroll: 1,
                infinite: true,
                dots: false,
                arrows: false,

            }
        },
        {
            breakpoint: 768,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 1,
                initialSlide: 1,
                arrows: false,

            }
        },
        {
            breakpoint: 600,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 1,
                initialSlide: 1,
                arrows: false,

            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
                arrows: false,


            }
        },
        {
            breakpoint: 375,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
                arrows: false,


            }
        },
        {
            breakpoint: 320,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                arrows: false,


            }
        }

    ]
}

function Char() {
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (loading) {
            setTimeout(() => {
                setLoading(false);
            }, 900);
        }
    }, [loading]);

    return (
        <Container fluid className="home-char" >

            {loading ? <Loading /> :
                (
                    <>
                        <Row>
                            <Col className="text-light mb-2 ">
                                <div className="home-row">
                                    <p className="home-char-title">کانال ها</p>
                                </div>
                        </Col>
                        </Row>
                        <Row >
                            <Col   >
                                <div  >
                                    <div className=" my-1 mb-2 mx-4  ">
                                        <Slider {...Setting}>
                                            {
                                                character.Characters.map((item, id) =>
                                                (<HomeCharCard item={item} key={id} />
                                                ))
                                            }
                                        </Slider>
                                    </div>
                                </div>
                              </Col>
                        </Row>
                    </>
                )}

    </Container>
       
  );
}

export default Char;

